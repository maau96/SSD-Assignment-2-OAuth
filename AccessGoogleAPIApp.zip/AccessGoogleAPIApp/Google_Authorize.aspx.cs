﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Gmail.v1;
using Google.Apis.Util.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AccessGoogleAPIApp
{
    public partial class Google_Authorize : System.Web.UI.Page
    {
        public static string ApplicationName= "Access Google API Client 1";
        public static string ClientId = "789677095342-h3o0pek2k3upjqrp2i7k0r4tsfvddn3s.apps.googleusercontent.com";
        public static string ClientSecret = "HYCOEqlLd6s2znvuAsNbb1u7";

        public static string[] Scope =
        {
            GmailService.Scope.GmailCompose,
            GmailService.Scope.GmailSend
        };

        public static UserCredential GetUserCredential(out string error)
        {
            UserCredential credential = null;
            error = string.Empty;

            try
            {
                credential = GoogleWebAuthorizationBroker.AuthorizeAsync(

                    new ClientSecrets
                    {
                        ClientId = ClientId,
                        ClientSecret = ClientSecret
                    },
                    Scope,
                    Environment.UserName,
                    CancellationToken.None,
                    new FileDataStore("Google Oaut2 Client Application")

                    ).Result;
            }
            catch (Exception ex)
            {
                credential = null;
                error = "Failed user credential initialization: " + ex.ToString();

            }
            return credential;
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnAuthorize_Click(object sender, EventArgs e)
        {
            string credentialError = string.Empty;
            string refreshToken = string.Empty;

            UserCredential credential = GetUserCredential(out credentialError);

            if (credential != null && string.IsNullOrWhiteSpace(credentialError))
            {
                refreshToken = credential.Token.RefreshToken;
            }
        }
    }
}